package uz.x96q.pult;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.hardware.ConsumerIrManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.text.InputType;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Locale;

/**
 * X96Q pult: telefonning IR nurlagichi orqali NEC protokolida buyruq yuboradi.
 * Box manzili va tugma kodlari avtomatik skaner bilan topiladi va saqlanadi.
 */
public class MainActivity extends Activity {

    private static final String PREFS = "x96q_pult";

    private static final int SCAN_NONE = 0;
    private static final int SCAN_ADDR = 1;
    private static final int SCAN_KEY = 2;

    private static final int UI_RUN = 0;
    private static final int UI_TUNE = 1;
    private static final int UI_END = 2;

    private static final int K_POWER = 0;
    private static final int K_MUTE = 1;
    private static final int K_HOME = 2;
    private static final int K_MENU = 3;
    private static final int K_BACK = 4;
    private static final int K_UP = 5;
    private static final int K_DOWN = 6;
    private static final int K_LEFT = 7;
    private static final int K_RIGHT = 8;
    private static final int K_OK = 9;
    private static final int K_VOLDN = 10;
    private static final int K_VOLUP = 11;
    private static final int NKEYS = 12;

    private static final String[] KEY_SHORT = {
            "Quvvat", "Ovoz yo'q", "Uy", "Menyu", "Orqaga",
            "↑", "↓", "←", "→", "OK",
            "Ovoz −", "Ovoz +"
    };
    private static final String[] KEY_LONG = {
            "Quvvat (yoqish / o'chirish)", "Ovozni o'chirish (Mute)", "Uy (Home)", "Menyu", "Orqaga (Back)",
            "Yuqoriga", "Pastga", "Chapga", "O'ngga", "OK (tanlash)",
            "Ovoz −", "Ovoz +"
    };
    private static final String[] KEY_HINT = {
            "box o'chsin yoki uyqu rejimiga o'tsin",
            "ovoz o'chsin yoki qaytib yonsin",
            "bosh ekranga chiqsin",
            "menyu ochilsin",
            "bir qadam orqaga qaytsin",
            "tanlov yuqoriga siljisin",
            "tanlov pastga siljisin",
            "tanlov chapga siljisin",
            "tanlov o'ngga siljisin",
            "tanlangan narsa ochilsin",
            "ovoz pasaysin",
            "ovoz ko'tarilsin"
    };

    private static final int BG = 0xFF101418;
    private static final int KEYCOL = 0xFF2B333B;
    private static final int BLUE = 0xFF1565C0;
    private static final int RED = 0xFFC62828;
    private static final int GREEN = 0xFF2E7D32;
    private static final int GREY = 0xFF455A64;

    /** Sinab ko'riladigan manzillar: {birinchi bayt, ikkinchi bayt}. Eng ehtimolli manzillar oldinda. */
    private static final int[][] ADDRS = buildAddrs();

    private static final int SCAN_INTERVAL_MS = 120;
    private static final int REWIND_ON_STOP = 6;

    // ---- IR va saqlangan sozlamalar ----
    private ConsumerIrManager ir;
    private int carrier = 38000;
    private SharedPreferences prefs;
    private int addrA = -1;
    private int addrB = -1;
    private final int[] keyCmd = new int[NKEYS];

    // ---- oqimlar ----
    private HandlerThread irThread;
    private Handler irHandler;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private volatile long lastErrToast = 0L;

    // ---- skaner holati ----
    private volatile boolean scanning = false;
    private volatile int scanMode = SCAN_NONE;
    private volatile int scanKey = 0;
    private volatile int scanIndex = 0;
    private volatile int scanLast = 0;
    private volatile int scanTotal = 0;
    private int testCount = 0;

    // ---- ko'rinishlar ----
    private LinearLayout panelPult;
    private LinearLayout panelSetup;
    private LinearLayout panelScan;
    private TextView txtStatus;
    private TextView txtSetupInfo;
    private EditText edA;
    private EditText edB;
    private final Button[] setupKeyBtns = new Button[NKEYS];
    private TextView scanTitle;
    private TextView scanHelp;
    private TextView scanCode;
    private TextView scanProgress;
    private Button btnStop;
    private Button btnSave;
    private Button btnCancel;
    private LinearLayout rowFine;

    // =====================================================================
    //  Hayot sikli
    // =====================================================================

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        loadPrefs();

        ir = (ConsumerIrManager) getSystemService(Context.CONSUMER_IR_SERVICE);
        if (hasIr()) {
            carrier = pickCarrier();
        }

        irThread = new HandlerThread("ir-sender");
        irThread.start();
        irHandler = new Handler(irThread.getLooper());

        buildUi();
        showPult();

        if (!hasIr()) {
            toast("Bu telefonda IR nurlagich topilmadi");
        }
    }

    @Override
    protected void onDestroy() {
        scanning = false;
        mainHandler.removeCallbacksAndMessages(null);
        if (irHandler != null) {
            irHandler.removeCallbacksAndMessages(null);
        }
        if (irThread != null) {
            irThread.quitSafely();
        }
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (panelScan.getVisibility() == View.VISIBLE) {
            stopScanQuiet();
            showSetup();
        } else if (panelSetup.getVisibility() == View.VISIBLE) {
            showPult();
        } else {
            super.onBackPressed();
        }
    }

    // =====================================================================
    //  Saqlash
    // =====================================================================

    private void loadPrefs() {
        addrA = prefs.getInt("a", -1);
        addrB = prefs.getInt("b", -1);
        for (int i = 0; i < NKEYS; i++) {
            keyCmd[i] = prefs.getInt("k" + i, -1);
        }
    }

    private void savePrefs() {
        SharedPreferences.Editor e = prefs.edit();
        e.putInt("a", addrA);
        e.putInt("b", addrB);
        for (int i = 0; i < NKEYS; i++) {
            e.putInt("k" + i, keyCmd[i]);
        }
        e.apply();
    }

    // =====================================================================
    //  IR yuborish (NEC)
    // =====================================================================

    private boolean hasIr() {
        try {
            return ir != null && ir.hasIrEmitter();
        } catch (Exception e) {
            return false;
        }
    }

    private int pickCarrier() {
        final int want = 38000;
        try {
            ConsumerIrManager.CarrierFrequencyRange[] ranges = ir.getCarrierFrequencies();
            if (ranges == null || ranges.length == 0) {
                return want;
            }
            int best = want;
            int bestDist = Integer.MAX_VALUE;
            for (ConsumerIrManager.CarrierFrequencyRange r : ranges) {
                int lo = r.getMinFrequency();
                int hi = r.getMaxFrequency();
                if (want >= lo && want <= hi) {
                    return want;
                }
                int dist = want < lo ? lo - want : want - hi;
                if (dist < bestDist) {
                    bestDist = dist;
                    best = want < lo ? lo : hi;
                }
            }
            return best;
        } catch (Exception e) {
            return want;
        }
    }

    /** NEC kadr: manzil(2 bayt) + buyruq + buyruqning inversiyasi. Faqat IR oqimidan chaqiriladi. */
    private void sendNec(int a, int b, int c) {
        if (!hasIr() || a < 0 || b < 0 || c < 0) {
            return;
        }
        int d = (~c) & 0xFF;
        int[] bytes = {a & 0xFF, b & 0xFF, c & 0xFF, d};
        int[] p = new int[67];
        int n = 0;
        p[n++] = 9000;
        p[n++] = 4500;
        for (int by : bytes) {
            for (int bit = 0; bit < 8; bit++) {
                p[n++] = 560;
                p[n++] = ((by >> bit) & 1) != 0 ? 1690 : 560;
            }
        }
        p[n++] = 560;
        try {
            ir.transmit(carrier, p);
        } catch (Exception e) {
            long now = System.currentTimeMillis();
            if (now - lastErrToast > 3000L) {
                lastErrToast = now;
                toast("IR yuborishda xato: " + e);
            }
        }
    }

    private void toast(final String msg) {
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(MainActivity.this, msg, Toast.LENGTH_LONG).show();
            }
        });
    }

    // =====================================================================
    //  Manzillar ro'yxati
    // =====================================================================

    private static int[][] buildAddrs() {
        ArrayList<int[]> list = new ArrayList<int[]>();
        boolean[] used = new boolean[256];
        int[] prio = {
                0x00, 0xFF, 0x40, 0xBF, 0x01, 0xFE, 0x04, 0xFB, 0x80, 0x7F,
                0x10, 0xEF, 0x20, 0xDF, 0x08, 0xF7, 0x02, 0xFD, 0x22, 0xDD,
                0x45, 0xBA, 0x4B, 0xB4, 0x18, 0xE7, 0x44, 0xBB, 0x86, 0x79
        };
        for (int a : prio) {
            if (!used[a]) {
                used[a] = true;
                list.add(new int[]{a, (~a) & 0xFF});
            }
        }
        // inversiyasiz (kengaytirilgan NEC) keng tarqalgan manzillar
        list.add(new int[]{0x40, 0x40});
        list.add(new int[]{0x00, 0x9F});
        list.add(new int[]{0x9F, 0x00});
        for (int a = 0; a < 256; a++) {
            if (!used[a]) {
                used[a] = true;
                list.add(new int[]{a, (~a) & 0xFF});
            }
        }
        return list.toArray(new int[list.size()][]);
    }

    /** Skaner ketma-ketligidagi i-kod: {A, B, buyruq}. */
    private int[] codeAt(int i) {
        if (scanMode == SCAN_ADDR) {
            int[] ab = ADDRS[Math.min(ADDRS.length - 1, i / 256)];
            return new int[]{ab[0], ab[1], i % 256};
        }
        return new int[]{Math.max(addrA, 0), Math.max(addrB, 0), i & 0xFF};
    }

    // =====================================================================
    //  Skaner
    // =====================================================================

    private final Runnable stepRunnable = new Runnable() {
        @Override
        public void run() {
            if (!scanning) {
                return;
            }
            long t0 = System.nanoTime();
            int i = scanIndex;
            // kalit o'rgatilayotganda "Quvvat" kodini o'tkazib yuboramiz (box o'chib qolmasin)
            if (scanMode == SCAN_KEY && scanKey != K_POWER && keyCmd[K_POWER] >= 0 && i == keyCmd[K_POWER]) {
                i++;
            }
            if (i >= scanTotal) {
                scanning = false;
                mainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        onScanEnded();
                    }
                });
                return;
            }
            scanIndex = i + 1;
            scanLast = i;
            int[] code = codeAt(i);
            sendNec(code[0], code[1], code[2]);
            final int shown = i;
            mainHandler.post(new Runnable() {
                @Override
                public void run() {
                    updateScanDisplay(shown);
                }
            });
            long used = (System.nanoTime() - t0) / 1000000L;
            long wait = Math.max(5L, SCAN_INTERVAL_MS - used);
            if (scanning) {
                irHandler.postDelayed(this, wait);
            }
        }
    };

    private final Runnable testRunnable = new Runnable() {
        @Override
        public void run() {
            if (testCount >= 45) {
                return;
            }
            testCount++;
            sendNec(0x00, 0xFF, 0x1C);
            irHandler.postDelayed(this, 110);
        }
    };

    private void startScan(int mode, int key) {
        if (!hasIr()) {
            toast("Bu telefonda IR nurlagich yo'q");
            return;
        }
        stopScanQuiet();
        scanMode = mode;
        scanKey = key;
        scanTotal = (mode == SCAN_ADDR) ? ADDRS.length * 256 : 256;
        scanIndex = 0;
        scanLast = 0;
        scanning = true;

        if (mode == SCAN_ADDR) {
            scanTitle.setText("1-qadam: box manzilini topish");
            scanHelp.setText("Box ulangan TV ekraniga qarang. Box biror narsa qilsa (menyu siljisa, ovoz o'zgarsa, ekran o'zgarsa) darhol TO'XTAT ni bosing. Har bir manzil taxminan 30 soniya oladi, eng ehtimollari birinchi sinaladi.");
        } else {
            scanTitle.setText("Tugma: " + KEY_LONG[key]);
            scanHelp.setText("TV ekraniga qarang. Kutilgan natija: " + KEY_HINT[key] + ". Shu bo'lishi bilan TO'XTAT ni bosing.");
        }
        scanCode.setText("...");
        scanProgress.setText("");
        setScanUi(UI_RUN);
        show(panelScan);
        irHandler.post(stepRunnable);
    }

    private void stopScanQuiet() {
        scanning = false;
        if (irHandler != null) {
            irHandler.removeCallbacks(stepRunnable);
            irHandler.removeCallbacks(testRunnable);
        }
        scanMode = SCAN_NONE;
    }

    private void onStopPressed() {
        scanning = false;
        irHandler.removeCallbacks(stepRunnable);
        irHandler.post(new Runnable() {
            @Override
            public void run() {
                final int cur = Math.max(0, scanLast - REWIND_ON_STOP);
                scanLast = cur;
                mainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        setScanUi(UI_TUNE);
                        updateScanDisplay(cur);
                    }
                });
            }
        });
    }

    /** Qo'lda sozlash: kodni delta ga siljitib (yoki shuni qayta) yuboradi. */
    private void stepCode(final int delta) {
        irHandler.post(new Runnable() {
            @Override
            public void run() {
                final int n = Math.max(0, Math.min(scanTotal - 1, scanLast + delta));
                scanLast = n;
                int[] c = codeAt(n);
                sendNec(c[0], c[1], c[2]);
                mainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        updateScanDisplay(n);
                    }
                });
            }
        });
    }

    private void onSavePressed() {
        int[] c = codeAt(scanLast);
        if (scanMode == SCAN_ADDR) {
            addrA = c[0];
            addrB = c[1];
            toast(String.format(Locale.US, "Manzil saqlandi: %02X %02X. Endi 2-qadam: tugmalarni o'rgating.", addrA, addrB));
        } else if (scanMode == SCAN_KEY) {
            keyCmd[scanKey] = c[2];
            toast(String.format(Locale.US, "\"%s\" saqlandi: kod %02X", KEY_LONG[scanKey], c[2]));
        }
        savePrefs();
        stopScanQuiet();
        showSetup();
    }

    private void onScanEnded() {
        setScanUi(UI_END);
        scanHelp.setText("Hamma kodlar sinab bo'lindi, lekin box javob bermadi. IR oynasini boxning IR ko'ziga yaqinroq va to'g'ri qaratib qayta urinib ko'ring.");
    }

    private void updateScanDisplay(int i) {
        int[] c = codeAt(i);
        scanCode.setText(String.format(Locale.US, "A=%02X  B=%02X  kod=%02X", c[0], c[1], c[2]));
        if (scanMode == SCAN_ADDR) {
            scanProgress.setText(String.format(Locale.US, "Manzil %d / %d   |   kod %d / 255", i / 256 + 1, ADDRS.length, i % 256));
        } else {
            scanProgress.setText(String.format(Locale.US, "Kod %d / 255", i));
        }
    }

    private void setScanUi(int state) {
        btnStop.setVisibility(state == UI_RUN ? View.VISIBLE : View.GONE);
        rowFine.setVisibility(state == UI_TUNE ? View.VISIBLE : View.GONE);
        btnSave.setVisibility(state == UI_TUNE ? View.VISIBLE : View.GONE);
        if (state == UI_TUNE) {
            if (scanMode == SCAN_ADDR) {
                scanHelp.setText("Box javob bergan kodni aniq topish uchun ← → bilan bittalab o'ting (har bosishda kod yuboriladi). Box aynan shu kodga javob bersa SAQLASH ni bosing.");
            } else {
                scanHelp.setText("← → bilan bittalab o'ting. Kutilgan natija: " + KEY_HINT[scanKey] + ". Aynan shu kodda bo'lsa SAQLASH ni bosing.");
            }
        }
    }

    // =====================================================================
    //  Pult tugmalari
    // =====================================================================

    private boolean keyReady(int key) {
        if (addrA < 0) {
            toast("Avval \"Sozlash\" ni bosib, box manzilini toping");
            return false;
        }
        if (keyCmd[key] < 0) {
            toast("\"" + KEY_LONG[key] + "\" hali o'rgatilmagan: Sozlash > 2-qadam");
            return false;
        }
        return true;
    }

    private void sendKey(int key) {
        final int a = addrA;
        final int b = addrB;
        final int c = keyCmd[key];
        irHandler.post(new Runnable() {
            @Override
            public void run() {
                sendNec(a, b, c);
            }
        });
    }

    private Button keyButton(final int key, int color) {
        final Button b = btn(KEY_SHORT[key], color);
        final boolean repeat = key != K_POWER;
        final Runnable rep = new Runnable() {
            @Override
            public void run() {
                sendKey(key);
                mainHandler.postDelayed(this, 130);
            }
        };
        b.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent ev) {
                int act = ev.getActionMasked();
                if (act == MotionEvent.ACTION_DOWN) {
                    v.setPressed(true);
                    v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
                    if (keyReady(key)) {
                        sendKey(key);
                        if (repeat) {
                            mainHandler.postDelayed(rep, 450);
                        }
                    }
                } else if (act == MotionEvent.ACTION_UP || act == MotionEvent.ACTION_CANCEL) {
                    v.setPressed(false);
                    mainHandler.removeCallbacks(rep);
                }
                return true;
            }
        });
        return b;
    }

    // =====================================================================
    //  Ko'rinishlar
    // =====================================================================

    private void show(LinearLayout panel) {
        panelPult.setVisibility(panel == panelPult ? View.VISIBLE : View.GONE);
        panelSetup.setVisibility(panel == panelSetup ? View.VISIBLE : View.GONE);
        panelScan.setVisibility(panel == panelScan ? View.VISIBLE : View.GONE);
    }

    private void showPult() {
        int learned = 0;
        for (int i = 0; i < NKEYS; i++) {
            if (keyCmd[i] >= 0) {
                learned++;
            }
        }
        if (addrA < 0) {
            txtStatus.setText("Hali sozlanmagan. Pastdagi \"Sozlash\" tugmasini bosing.");
        } else {
            txtStatus.setText(String.format(Locale.US, "Manzil: %02X %02X   |   o'rgatilgan tugmalar: %d / %d", addrA, addrB, learned, NKEYS));
        }
        show(panelPult);
    }

    private void showSetup() {
        if (addrA < 0) {
            txtSetupInfo.setText("Box manzili: topilmagan");
        } else {
            txtSetupInfo.setText(String.format(Locale.US, "Box manzili: %02X %02X", addrA, addrB));
        }
        for (int i = 0; i < NKEYS; i++) {
            String mark = keyCmd[i] >= 0 ? String.format(Locale.US, "   ✓ %02X", keyCmd[i]) : "   —";
            setupKeyBtns[i].setText(KEY_LONG[i] + mark);
        }
        show(panelSetup);
    }

    private void buildUi() {
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(BG);
        sv.setFillViewport(true);
        sv.setKeepScreenOn(true);

        LinearLayout root = vbox();
        root.setPadding(dp(16), dp(28), dp(16), dp(28));
        sv.addView(root);

        panelPult = vbox();
        panelSetup = vbox();
        panelScan = vbox();
        root.addView(panelPult);
        root.addView(panelSetup);
        root.addView(panelScan);

        buildPultPanel();
        buildSetupPanel();
        buildScanPanel();

        setContentView(sv);
    }

    private void buildPultPanel() {
        panelPult.addView(text("X96Q pult", 26, true));
        txtStatus = text("", 13, false);
        txtStatus.setTextColor(0xFFB0BEC5);
        panelPult.addView(txtStatus);

        LinearLayout r1 = hrow();
        r1.addView(keyButton(K_POWER, RED), lp(0, dp(56), 1f, dp(4)));
        r1.addView(keyButton(K_MUTE, KEYCOL), lp(0, dp(56), 1f, dp(4)));
        panelPult.addView(r1);

        LinearLayout r2 = hrow();
        r2.addView(keyButton(K_HOME, KEYCOL), lp(0, dp(56), 1f, dp(4)));
        r2.addView(keyButton(K_MENU, KEYCOL), lp(0, dp(56), 1f, dp(4)));
        r2.addView(keyButton(K_BACK, KEYCOL), lp(0, dp(56), 1f, dp(4)));
        panelPult.addView(r2);

        panelPult.addView(new View(this), lp(LinearLayout.LayoutParams.MATCH_PARENT, dp(14), 0f, 0));

        LinearLayout up = hrow();
        up.addView(new View(this), lp(0, dp(72), 1f, dp(4)));
        up.addView(keyButton(K_UP, BLUE), lp(0, dp(72), 1f, dp(4)));
        up.addView(new View(this), lp(0, dp(72), 1f, dp(4)));
        panelPult.addView(up);

        LinearLayout mid = hrow();
        mid.addView(keyButton(K_LEFT, BLUE), lp(0, dp(72), 1f, dp(4)));
        mid.addView(keyButton(K_OK, GREEN), lp(0, dp(72), 1f, dp(4)));
        mid.addView(keyButton(K_RIGHT, BLUE), lp(0, dp(72), 1f, dp(4)));
        panelPult.addView(mid);

        LinearLayout down = hrow();
        down.addView(new View(this), lp(0, dp(72), 1f, dp(4)));
        down.addView(keyButton(K_DOWN, BLUE), lp(0, dp(72), 1f, dp(4)));
        down.addView(new View(this), lp(0, dp(72), 1f, dp(4)));
        panelPult.addView(down);

        panelPult.addView(new View(this), lp(LinearLayout.LayoutParams.MATCH_PARENT, dp(14), 0f, 0));

        LinearLayout vol = hrow();
        vol.addView(keyButton(K_VOLDN, KEYCOL), lp(0, dp(60), 1f, dp(4)));
        vol.addView(keyButton(K_VOLUP, KEYCOL), lp(0, dp(60), 1f, dp(4)));
        panelPult.addView(vol);

        panelPult.addView(new View(this), lp(LinearLayout.LayoutParams.MATCH_PARENT, dp(20), 0f, 0));

        Button setup = btn("Sozlash", GREY);
        setup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showSetup();
            }
        });
        panelPult.addView(setup, lp(LinearLayout.LayoutParams.MATCH_PARENT, dp(52), 0f, dp(4)));
    }

    private void buildSetupPanel() {
        panelSetup.addView(text("Sozlash", 24, true));
        txtSetupInfo = text("", 14, false);
        txtSetupInfo.setTextColor(0xFFB0BEC5);
        panelSetup.addView(txtSetupInfo);

        TextView tip = text("Telefonning IR oynasini boxning old tomoniga (ko'k chiroq yonidagi IR ko'ziga) qaratib, 1-2 metr masofada ushlang. Redmi'da IR oynasi odatda telefonning yuqori chetida bo'ladi. Telefon g'ilofi bo'lsa, olib qo'ying.", 13, false);
        tip.setTextColor(0xFFB0BEC5);
        panelSetup.addView(tip);

        Button test = btn("IR nurini sinash (5 soniya)", GREY);
        test.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startIrTest();
            }
        });
        panelSetup.addView(test, lp(LinearLayout.LayoutParams.MATCH_PARENT, dp(48), 0f, dp(4)));

        panelSetup.addView(text("1-qadam: box manzili", 17, true));
        Button scan = btn("Manzilni avtomatik topish (skaner)", BLUE);
        scan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startScan(SCAN_ADDR, 0);
            }
        });
        panelSetup.addView(scan, lp(LinearLayout.LayoutParams.MATCH_PARENT, dp(52), 0f, dp(4)));

        TextView manual = text("Yoki qo'lda kiriting (hex, masalan 00 va FF; ikkinchisini bo'sh qoldirsangiz inversiya olinadi):", 13, false);
        manual.setTextColor(0xFFB0BEC5);
        panelSetup.addView(manual);
        LinearLayout mrow = hrow();
        edA = edit("A (hex)");
        edB = edit("B (hex)");
        Button msave = btn("Saqlash", GREY);
        msave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveManualAddress();
            }
        });
        mrow.addView(edA, lp(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f, dp(4)));
        mrow.addView(edB, lp(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f, dp(4)));
        mrow.addView(msave, lp(0, dp(48), 1f, dp(4)));
        panelSetup.addView(mrow);

        panelSetup.addView(text("2-qadam: tugmalarni o'rgatish", 17, true));
        TextView t2 = text("Tugmani bosing, app kodlarni birma-bir yuboradi. TV ekraniga qarab, kutilgan natija chiqqanda TO'XTAT ni bosing. Birinchi bo'lib \"Quvvat\" ni o'rgating.", 13, false);
        t2.setTextColor(0xFFB0BEC5);
        panelSetup.addView(t2);

        for (int i = 0; i < NKEYS; i++) {
            final int key = i;
            Button b = btn(KEY_LONG[i], KEYCOL);
            b.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (addrA < 0) {
                        toast("Avval 1-qadam: box manzilini toping");
                    } else {
                        startScan(SCAN_KEY, key);
                    }
                }
            });
            setupKeyBtns[i] = b;
            panelSetup.addView(b, lp(LinearLayout.LayoutParams.MATCH_PARENT, dp(48), 0f, dp(3)));
        }

        Button reset = btn("Hamma sozlamalarni o'chirish", RED);
        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addrA = -1;
                addrB = -1;
                for (int i = 0; i < NKEYS; i++) {
                    keyCmd[i] = -1;
                }
                savePrefs();
                showSetup();
            }
        });
        panelSetup.addView(reset, lp(LinearLayout.LayoutParams.MATCH_PARENT, dp(48), 0f, dp(4)));

        Button back = btn("Pultga qaytish", GREEN);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPult();
            }
        });
        panelSetup.addView(back, lp(LinearLayout.LayoutParams.MATCH_PARENT, dp(52), 0f, dp(4)));
    }

    private void buildScanPanel() {
        scanTitle = text("", 20, true);
        panelScan.addView(scanTitle);
        scanHelp = text("", 14, false);
        scanHelp.setTextColor(0xFFB0BEC5);
        panelScan.addView(scanHelp);

        scanCode = text("", 24, true);
        scanCode.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        panelScan.addView(scanCode);
        scanProgress = text("", 14, false);
        scanProgress.setTextColor(0xFFB0BEC5);
        panelScan.addView(scanProgress);

        btnStop = btn("TO'XTAT — box javob berdi!", RED);
        btnStop.setTextSize(20f);
        btnStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onStopPressed();
            }
        });
        panelScan.addView(btnStop, lp(LinearLayout.LayoutParams.MATCH_PARENT, dp(96), 0f, dp(6)));

        rowFine = hrow();
        Button prev = btn("← oldingi", KEYCOL);
        prev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stepCode(-1);
            }
        });
        Button again = btn("Qayta yubor", BLUE);
        again.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stepCode(0);
            }
        });
        Button next = btn("keyingi →", KEYCOL);
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stepCode(1);
            }
        });
        rowFine.addView(prev, lp(0, dp(64), 1f, dp(4)));
        rowFine.addView(again, lp(0, dp(64), 1f, dp(4)));
        rowFine.addView(next, lp(0, dp(64), 1f, dp(4)));
        panelScan.addView(rowFine);

        btnSave = btn("SAQLASH", GREEN);
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onSavePressed();
            }
        });
        panelScan.addView(btnSave, lp(LinearLayout.LayoutParams.MATCH_PARENT, dp(56), 0f, dp(6)));

        btnCancel = btn("Bekor qilish", GREY);
        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopScanQuiet();
                showSetup();
            }
        });
        panelScan.addView(btnCancel, lp(LinearLayout.LayoutParams.MATCH_PARENT, dp(48), 0f, dp(6)));
    }

    private void saveManualAddress() {
        int a = parseHex(edA.getText().toString());
        if (a < 0 || a > 255) {
            toast("A qiymati noto'g'ri. 00 dan FF gacha hex kiriting.");
            return;
        }
        String bs = edB.getText().toString().trim();
        int b = bs.isEmpty() ? ((~a) & 0xFF) : parseHex(bs);
        if (b < 0 || b > 255) {
            toast("B qiymati noto'g'ri. 00 dan FF gacha hex kiriting.");
            return;
        }
        addrA = a;
        addrB = b;
        savePrefs();
        toast(String.format(Locale.US, "Manzil saqlandi: %02X %02X", a, b));
        showSetup();
    }

    private int parseHex(String s) {
        try {
            String t = s.trim();
            if (t.startsWith("0x") || t.startsWith("0X")) {
                t = t.substring(2);
            }
            return Integer.parseInt(t, 16);
        } catch (Exception e) {
            return -1;
        }
    }

    private void startIrTest() {
        if (!hasIr()) {
            toast("Bu telefonda IR nurlagich yo'q");
            return;
        }
        toast("5 soniya IR yuboriladi. Boshqa telefonning old kamerasida IR nuri binafsha chiroq bo'lib ko'rinishi kerak.");
        irHandler.removeCallbacks(testRunnable);
        irHandler.post(new Runnable() {
            @Override
            public void run() {
                testCount = 0;
                testRunnable.run();
            }
        });
    }

    // =====================================================================
    //  Kichik yordamchilar
    // =====================================================================

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private LinearLayout vbox() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private LinearLayout hrow() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        return l;
    }

    private LinearLayout.LayoutParams lp(int w, int h, float weight, int margin) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h, weight);
        p.setMargins(margin, margin, margin, margin);
        return p;
    }

    private TextView text(String s, float sp, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(Color.WHITE);
        if (bold) {
            t.setTypeface(Typeface.DEFAULT_BOLD);
        }
        t.setPadding(0, dp(6), 0, dp(6));
        return t;
    }

    private EditText edit(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(0xFF78909C);
        e.setTextColor(Color.WHITE);
        e.setSingleLine(true);
        e.setInputType(InputType.TYPE_CLASS_TEXT
                | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
                | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        return e;
    }

    private Button btn(String label, int color) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setTextSize(16f);
        b.setBackground(roundBg(color));
        return b;
    }

    private StateListDrawable roundBg(int color) {
        StateListDrawable s = new StateListDrawable();
        s.addState(new int[]{android.R.attr.state_pressed}, shape(lighten(color)));
        s.addState(new int[]{}, shape(color));
        return s;
    }

    private GradientDrawable shape(int color) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(14));
        return g;
    }

    private int lighten(int c) {
        int r = Math.min(255, Color.red(c) + 70);
        int g = Math.min(255, Color.green(c) + 70);
        int b = Math.min(255, Color.blue(c) + 70);
        return Color.rgb(r, g, b);
    }
}
